﻿Public Class Title
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show("October 30, 2018" + Environment.NewLine +
                        "Open ""Mic""" + Environment.NewLine +
                        "Start Time 8:00 PM" + Environment.NewLine +
                        "For more information, view Campus Music Café Facebook Page.")
    End Sub
End Class
